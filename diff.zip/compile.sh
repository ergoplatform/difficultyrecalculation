#!/usr/bin/env bash
pdflatex diff
bibtex diff
pdflatex diff
pdflatex diff
